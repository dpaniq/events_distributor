https://www.geeksforgeeks.org/writing-data-from-a-python-list-to-csv-row-wise/

import csv
from random import choice
from pprint import pprint

# Read file
# * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
actualEvents = []
with open('events.csv', 'r') as file:
  csvreader = csv.reader(file)
  for row in csvreader:
    actualEvents.append(row[2:4][::-1])


# Uniq value for key
# * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
actualEventsDict = {}
for key, value in actualEvents:
  actualEventsDict[key] = value
# pprint(actualEventsDict)


# Grouping by segment
# * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
actualEventsNewDict = {}
for key, value in actualEventsDict.items():
  if value not in actualEventsNewDict:
    actualEventsNewDict[value] = []
  actualEventsNewDict[value].append(key)
  actualEventsNewDict[value].append(key)
# pprint(actualEventsNewDict)


# Razspredeleine
# * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
generateCSV = {}
expertsColumnNumber = 30
meetingRowNumber = 6

"""
[
  ['asd', 'asd', 'asd'],
  ['asd', 'asd', 'asd'],
  ['asd', 'asd', 'asd'],
  ['asd', 'asd', 'asd'], -> row
                  ^ column
]
"""

for key in actualEventsNewDict.keys():
  print('actual events new dict', len(actualEventsNewDict[key]))
  
  rows = []
  for row in range(meetingRowNumber):
    columns = []
    for column in range(expertsColumnNumber):
      if len(actualEventsNewDict[key]) > 0:
        choosen = choice(actualEventsNewDict[key])
        columns.append(choosen)
        actualEventsNewDict[key].remove(choosen) # delete one of project
    rows.append(columns)
  generateCSV[key] = rows
      
# pprint(generateCSV)


# Write file
# * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *

firstKey = list(generateCSV.keys())[0]

# print(generateCSV[firstKey])
# [['asdasd', ...], [], []]

file = open(f'{key}.csv', 'w', newline ='')
with file:   
    write = csv.writer(file)
    for row in generateCSV[firstKey]:
      write.writerows([row])
 
# opening the csv file in 'w+' mode

 
# writing the data into the file



# import pandas as pd

# df = pd.DataFrame(generateCSV)      
# df.to_excel('./teams.xlsx')


# firstKey = (generateCSV.keys())[0]
# with open('file.csv', 'w', newline='') as csvfile:
#   spamwriter = csv.writer(csvfile, delimiter=' ', quotechar='|', quoting=csv.QUOTE_MINIMAL)
  
#   for row in generateCSV[firstKey]:
#     spamwriter.writerow(row)
  
